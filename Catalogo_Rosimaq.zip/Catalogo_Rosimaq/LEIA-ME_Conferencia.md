# Catálogo Rosimaq

| Nº | Produto | Arquivo |
|---|---|---|
| 01 | Betoneira 400 L Monofásica 220V, Menegotti Prime 400 | 01_Betoneira_Menegotti_Prime_400L_220V.jpg |
| 02 | Martelete Rompedor Arita 5 kg, 1300W, 220V | 02_Martelete_Rompedor_Arita_5kg_1300W_220V.jpg |
| 03 | Martelete Perfurador 5 kg, 1600W, 220V | 03_Martelete_Perfurador_5kg_1600W_220V.jpg |
| 04 | Vibrador de concreto com mangote 1,2 m, 1000W, 220V | 04_Vibrador_Concreto_com_Mangote_Menegotti_1000W_220V.jpg |
| 05 | Vibrador de concreto com mangote 35 mm, 2,5 m, 1000W, 220V | 05_Vibrador_Concreto_com_Mangote_35mm_2,5m_Menegotti_1000W_220V.jpg |
| 06 | Andaime profissional de aço 1,00 x 1,00, NR18 | 06_Andaime_Profissional_Aco_1,00x1,00_NR18.jpg |
| 07 | Andaime profissional de aço 1,00 x 1,50, NR18 | 07_Andaime_Profissional_Aco_1,00x1,50_NR18.jpg |
| 08 | Extensão elétrica 50 m, 20A, cabo PP 2x1,5 | 08_Extensao_Eletrica_50m_20A_Cabo_PP_2x1,5.jpg |
| 09 | Corda de bombeiro 50 m, 12 mm, NR18, estaiamento de andaime | 09_Corda_Bombeiro_50m_12mm_NR18_Estaiamento.jpg |
| 10 | Escada extensível fibra de vidro 25 degraus, 4,50 a 7,80 m | 10_Escada_Extensivel_Fibra_Vidro_25_Degraus_4,50_a_7,80m.jpg |
| 11 | Escada extensiva em D vazada, 3,60 fechada e 6,00 m | 11_Escada_Extensiva_Degraus_em_D_Vazada_3,60_a_6,00m.jpg |
| 12 | Escada alumínio e fibra de vidro extensível 8,4 m, 27 degraus | 12_Escada_Aluminio_Fibra_Vidro_Extensivel_8,4m_27_Degraus.jpg |
